/* Copyright (C) 2016 STMicroelectronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 *
 * File Name		: ais3624dq_acc.c
 * Authors		: VMA - Volume Mems & Analog Division
 *			: Matteo Dameno (matteo.dameno@st.com)
 *			: Lorenzo Bianconi (lorenzo.bianconi@st.com)
 *			: Mario Tesi (mario.tesi@st.com)
 *			: Authors is willing to be considered the contact
 *			: and update point for the driver.
 * Version		: V 1.0.2
 * Date			: 2016/06/06
 * Description		: AIS3624DQ 3D accelerometer sensor
 *
 ******************************************************************************
 * Revision 1.0.0 2011/03/02
 *	first release
 * Revision 1.0.1 2012/10/07
 *	corrects default permissions on sysfs files
 * Revision 1.0.2 2016/06/06
 *	added spi support and suspend/resume capabilities
 *****************************************************************************/

#include <linux/err.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/input.h>
#include <linux/uaccess.h>
#include <linux/workqueue.h>
#include <linux/irq.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/module.h>

#include "ais3624dq.h"

#define SENSITIVITY_6G		1	/**	mg/LSB	*/
#define SENSITIVITY_12G		2	/**	mg/LSB	*/
#define SENSITIVITY_24G		4	/**	mg/LSB	*/

#define AXISDATA_REG		0x28
#define WHOAMI_AIS3624DQ_ACC	0x32	/*	Expctd content for WAI	*/

/*	CONTROL REGISTERS ADDRESSES	*/
#define WHO_AM_I		0x0F	/*	WhoAmI register		*/
#define CTRL_REG1		0x20	/*				*/
#define CTRL_REG2		0x21	/*				*/
#define CTRL_REG3		0x22	/*				*/
#define CTRL_REG4		0x23	/*				*/
#define	CTRL_REG5		0x24	/*				*/

#define	INT_CFG1		0x30	/*	interrupt 1 config	*/
#define	INT_SRC1		0x31	/*	interrupt 1 source	*/
#define	INT_THS1		0x32	/*	interrupt 1 threshold	*/
#define	INT_DUR1		0x33	/*	interrupt 1 duration	*/

#define	INT_CFG2		0x34	/*	interrupt 2 config	*/
#define	INT_SRC2		0x35	/*	interrupt 2 source	*/
#define	INT_THS2		0x36	/*	interrupt 2 threshold	*/
#define	INT_DUR2		0x37	/*	interrupt 2 duration	*/
/*	end CONTROL REGISTRES ADDRESSES	*/

#define AIS3624DQ_ACC_ENABLE_ALL_AXES	0x07
#define AIS3624DQ_SELFTEST_EN	0x02
#define AIS3624DQ_SELFTEST_DIS	0x00
#define AIS3624DQ_SELFTEST_POS	0x00
#define AIS3624DQ_SELFTEST_NEG	0x08

#define AIS3624DQ_ACC_BDU_EN	0x80

/* Accelerometer output data rate  */
#define AIS3624DQ_ACC_ODRHALF	0x40	/* 0.5Hz output data rate */
#define AIS3624DQ_ACC_ODR1	0x60	/* 1Hz output data rate */
#define AIS3624DQ_ACC_ODR2	0x80	/* 2Hz output data rate */
#define AIS3624DQ_ACC_ODR5	0xA0	/* 5Hz output data rate */
#define AIS3624DQ_ACC_ODR10	0xC0	/* 10Hz output data rate */
#define AIS3624DQ_ACC_ODR50	0x00	/* 50Hz output data rate */
#define AIS3624DQ_ACC_ODR100	0x08	/* 100Hz output data rate */
#define AIS3624DQ_ACC_ODR400	0x10	/* 400Hz output data rate */
#define AIS3624DQ_ACC_ODR1000	0x18	/* 1000Hz output data rate */

/* RESUME STATE INDICES */
#define	RES_CTRL_REG1	0
#define	RES_CTRL_REG2	1
#define	RES_CTRL_REG3	2
#define	RES_CTRL_REG4	3
#define	RES_CTRL_REG5	4
#define	RES_REFERENCE	5

#define	RES_INT_CFG1	6
#define	RES_INT_THS1	7
#define	RES_INT_DUR1	8
#define	RES_INT_CFG2	9
#define	RES_INT_THS2	10
#define	RES_INT_DUR2	11

/* end RESUME STATE INDICES */

#define INPUT_EVENT_TYPE	EV_MSC
#define INPUT_EVENT_X		MSC_SERIAL
#define INPUT_EVENT_Y		MSC_PULSELED
#define INPUT_EVENT_Z		MSC_GESTURE

static struct {
	unsigned int cutoff_ms;
	unsigned int mask;
} ais3624dq_acc_odr_table[] = {
	{1, AIS3624DQ_ACC_PM_NORMAL | AIS3624DQ_ACC_ODR1000},
	{3, AIS3624DQ_ACC_PM_NORMAL | AIS3624DQ_ACC_ODR400},
	{10, AIS3624DQ_ACC_PM_NORMAL | AIS3624DQ_ACC_ODR100},
	{20, AIS3624DQ_ACC_PM_NORMAL | AIS3624DQ_ACC_ODR50},
	/* low power settings, max low pass filter cut-off freq */
	{100, AIS3624DQ_ACC_ODR10 | AIS3624DQ_ACC_ODR1000},
	{200, AIS3624DQ_ACC_ODR5 | AIS3624DQ_ACC_ODR1000},
	{5000, AIS3624DQ_ACC_ODR2 | AIS3624DQ_ACC_ODR1000 },
	{1000, AIS3624DQ_ACC_ODR1 | AIS3624DQ_ACC_ODR1000 },
	{2000, AIS3624DQ_ACC_ODRHALF | AIS3624DQ_ACC_ODR1000 },
};

static int ais3624dq_acc_hw_init(struct ais3624dq_acc_data *acc)
{
	int err = -1;
	u8 buf[4];

	printk(KERN_INFO "%s: hw init start\n", AIS3624DQ_ACC_DEV_NAME);

	err = acc->tf->read(acc->dev, WHO_AM_I, 1, buf);
	if (err < 0){
		dev_warn(acc->dev, "Error reading WHO_AM_I: is device "
			"available/working?\n");
		goto err_firstread;
	} else
		acc->hw_working = 1;
	if (buf[0] != WHOAMI_AIS3624DQ_ACC) {
		dev_err(acc->dev,
			"device unknown. Expected: 0x%x,"
			" Replies: 0x%x\n", WHOAMI_AIS3624DQ_ACC, buf[0]);
		err = -1; /* choose the right coded error */
		goto err_unknown_device;
	}

	buf[0] = acc->resume_state[RES_CTRL_REG1];
	err = acc->tf->write(acc->dev, CTRL_REG1, 1, buf);
	if (err < 0)
		goto err_resume_state;

	buf[0] = acc->resume_state[RES_INT_THS1];
	buf[1] = acc->resume_state[RES_INT_DUR1];
	err = acc->tf->write(acc->dev, INT_THS1, 2, buf);
	if (err < 0)
		goto err_resume_state;

	buf[0] = acc->resume_state[RES_INT_CFG1];
	err = acc->tf->write(acc->dev, INT_CFG1, 1, buf);
	if (err < 0)
		goto err_resume_state;

	buf[0] = acc->resume_state[RES_INT_THS2];
	buf[1] = acc->resume_state[RES_INT_DUR2];
	err = acc->tf->write(acc->dev, INT_THS2, 2, buf);
	if (err < 0)
		goto err_resume_state;

	buf[0] = acc->resume_state[RES_INT_CFG2];
	err = acc->tf->write(acc->dev, INT_CFG2, 1, buf);
	if (err < 0)
		goto err_resume_state;

	buf[0] = acc->resume_state[RES_CTRL_REG2];
	buf[1] = acc->resume_state[RES_CTRL_REG3];
	buf[2] = acc->resume_state[RES_CTRL_REG4];
	buf[3] = acc->resume_state[RES_CTRL_REG5];
	err = acc->tf->write(acc->dev, CTRL_REG2, 4, buf);
	if (err < 0)
		goto err_resume_state;

	acc->hw_initialized = 1;
	printk(KERN_INFO "%s: hw init done\n", AIS3624DQ_ACC_DEV_NAME);
	return 0;

err_firstread:
	acc->hw_working = 0;
err_unknown_device:
err_resume_state:
	acc->hw_initialized = 0;
	dev_err(acc->dev, "hw init error 0x%x,0x%x: %d\n", buf[0],
			buf[1], err);

	return err;
}

static void ais3624dq_acc_device_power_off(struct ais3624dq_acc_data *acc)
{
	int err;
	u8 buf[1] = {AIS3624DQ_ACC_PM_OFF};

	err = acc->tf->write(acc->dev, CTRL_REG1, 1, buf);
	if (err < 0)
		dev_err(acc->dev, "soft power off failed: %d\n", err);

	if (acc->pdata->power_off) {
		if(acc->pdata->gpio_int1 >= 0)
			disable_irq_nosync(acc->irq1);
		if(acc->pdata->gpio_int2 >= 0)
			disable_irq_nosync(acc->irq2);
		acc->pdata->power_off();
		acc->hw_initialized = 0;
	}
	if (acc->hw_initialized) {
		if(acc->pdata->gpio_int1 >= 0)
			disable_irq_nosync(acc->irq1);
		if(acc->pdata->gpio_int2 >= 0)
			disable_irq_nosync(acc->irq2);
		acc->hw_initialized = 0;
	}
}

static int ais3624dq_acc_device_power_on(struct ais3624dq_acc_data *acc)
{
	int err = -1;

	if (acc->pdata->power_on) {
		err = acc->pdata->power_on();
		if (err < 0) {
			dev_err(acc->dev,
				"power_on failed: %d\n", err);
			return err;
		}
		if(acc->pdata->gpio_int1 >= 0)
			enable_irq(acc->irq1);
		if(acc->pdata->gpio_int2 >= 0)
			enable_irq(acc->irq2);
	}

	if (!acc->hw_initialized) {
		err = ais3624dq_acc_hw_init(acc);
		if (acc->hw_working == 1 && err < 0) {
			ais3624dq_acc_device_power_off(acc);
			return err;
		}
	}

	if (acc->hw_initialized) {
		if(acc->pdata->gpio_int1 >= 0)
			enable_irq(acc->irq1);
		if(acc->pdata->gpio_int2 >= 0)
			enable_irq(acc->irq2);
	}

	return 0;
}

static irqreturn_t ais3624dq_acc_isr1(int irq, void *dev)
{
	struct ais3624dq_acc_data *acc = dev;

	disable_irq_nosync(irq);
	queue_work(acc->irq1_work_queue, &acc->irq1_work);
	printk(KERN_INFO "%s: isr1 queued\n", AIS3624DQ_ACC_DEV_NAME);

	return IRQ_HANDLED;
}

static irqreturn_t ais3624dq_acc_isr2(int irq, void *dev)
{
	struct ais3624dq_acc_data *acc = dev;

	disable_irq_nosync(irq);
	queue_work(acc->irq2_work_queue, &acc->irq2_work);
	printk(KERN_INFO "%s: isr2 queued\n", AIS3624DQ_ACC_DEV_NAME);

	return IRQ_HANDLED;
}

static void ais3624dq_acc_irq1_work_func(struct work_struct *work)
{
	struct ais3624dq_acc_data *acc =
	container_of(work, struct ais3624dq_acc_data, irq1_work);
	/* TODO  add interrupt service procedure.
		 ie:ais3624dq_acc_get_int1_source(acc); */
	enable_irq(acc->irq1);
}

static void ais3624dq_acc_irq2_work_func(struct work_struct *work)
{
	struct ais3624dq_acc_data *acc =
	container_of(work, struct ais3624dq_acc_data, irq2_work);
	/* TODO  add interrupt service procedure.
		 ie:ais3624dq_acc_get_tap_source(acc); */
	enable_irq(acc->irq2);
}

int ais3624dq_acc_update_g_range(struct ais3624dq_acc_data *acc, u8 new_g_range)
{
	int err = -1;
	u8 sensitivity;
	u8 buf[1];
	u8 updated_val;
	u8 init_val;
	u8 new_val;
	u8 mask = AIS3624DQ_ACC_FS_MASK;

	switch (new_g_range) {
	case AIS3624DQ_ACC_G_6G:
		sensitivity = SENSITIVITY_6G;
		break;
	case AIS3624DQ_ACC_G_12G:
		sensitivity = SENSITIVITY_12G;
		break;
	case AIS3624DQ_ACC_G_24G:
		sensitivity = SENSITIVITY_24G;
		break;
	default:
		dev_err(acc->dev, "invalid g range requested: %u\n",
			new_g_range);
		return -EINVAL;
	}

	if (atomic_read(&acc->enabled)) {
		/* Set configuration register 4, which contains g range setting
		 *  NOTE: this is a straight overwrite because this driver does
		 *  not use any of the other configuration bits in this
		 *  register.  Should this become untrue, we will have to read
		 *  out the value and only change the relevant bits --XX----
		 *  (marked by X) */
		err = acc->tf->read(acc->dev, CTRL_REG4, 1, buf);
		if (err < 0)
			goto error;

		init_val = buf[0];
		acc->resume_state[RES_CTRL_REG4] = init_val;
		new_val = new_g_range;
		updated_val = ((mask & new_val) | ((~mask) & init_val));
		buf[0] = updated_val;
		err = acc->tf->write(acc->dev, CTRL_REG4, 1, buf);
		if (err < 0)
			goto error;

		acc->resume_state[RES_CTRL_REG4] = updated_val;
		acc->sensitivity = sensitivity;
	}

	return err;
error:
	dev_err(acc->dev, "update g range failed 0x%x: %d\n",
		buf[0], err);

	return err;
}

int ais3624dq_acc_update_odr(struct ais3624dq_acc_data *acc,
			     int poll_interval_ms)
{
	int err = -1;
	int i;
	u8 config;

	/* Following, looks for the longest possible odr interval scrolling the
	 * odr_table vector from the end (shortest interval) backward (longest
	 * interval), to support the poll_interval requested by the system.
	 * It must be the longest interval lower then the poll interval.*/
	for (i = ARRAY_SIZE(ais3624dq_acc_odr_table) - 1; i >= 0; i--) {
		if (ais3624dq_acc_odr_table[i].cutoff_ms <= poll_interval_ms)
			break;
	}

	config = ais3624dq_acc_odr_table[i].mask;
	config |= AIS3624DQ_ACC_ENABLE_ALL_AXES;

	/* If device is currently enabled, we need to write new
	 *  configuration out to it */
	if (atomic_read(&acc->enabled)) {
		err = acc->tf->write(acc->dev, CTRL_REG1, 1, &config);
		if (err < 0)
			goto error;
	}
	acc->resume_state[RES_CTRL_REG1] = config;

	return err;

error:
	dev_err(acc->dev, "update odr failed 0x%x: %d\n",
		config, err);

	return err;
}

static int ais3624dq_acc_register_update(struct ais3624dq_acc_data *acc,
					 u8 *buf, u8 reg_address, u8 mask,
					 u8 new_bit_values)
{
	int err = -1;
	u8 init_val;
	u8 updated_val;

	err = acc->tf->read(acc->dev, reg_address, 1, buf);
	if (!(err < 0)) {
		init_val = buf[1];
		updated_val = ((mask & new_bit_values) | (~mask & init_val));
		err = acc->tf->write(acc->dev, reg_address, 1, &updated_val);
	}

	return err;
}

static int ais3624dq_acc_selftest(struct ais3624dq_acc_data *acc, u8 enable)
{
	int err = -1;
	u8 buf[2] = {0x00, 0x00};
	char reg_address = CTRL_REG4, mask = 0x0A, bit_values;

	if (enable > 0)
		bit_values = AIS3624DQ_SELFTEST_EN |
			     AIS3624DQ_SELFTEST_POS;
	else
		bit_values = AIS3624DQ_SELFTEST_DIS |
			     AIS3624DQ_SELFTEST_POS;

	if (atomic_read(&acc->enabled)) {
		mutex_lock(&acc->lock);
		err = ais3624dq_acc_register_update(acc, buf, reg_address,
						    mask, bit_values);
		acc->selftest_enabled = enable;
		mutex_unlock(&acc->lock);
		if (err < 0)
			return err;

		acc->resume_state[RES_CTRL_REG4] = ((mask & bit_values) |
				( ~mask & acc->resume_state[RES_CTRL_REG4]));
	}

	return err;
}

static int ais3624dq_acc_get_acceleration_data(struct ais3624dq_acc_data *acc,
					       int *xyz)
{
	int err = -1;
	/* Data bytes from hardware xL, xH, yL, yH, zL, zH */
	u8 acc_data[6];
	/* x,y,z hardware data */
	s16 hw_d[3] = { 0 };

	err = acc->tf->read(acc->dev, AXISDATA_REG, 6, acc_data);
	if (err < 0)
		return err;
	/* Out data is 12 bit left just. */
	hw_d[0] = (((s16)((acc_data[1] << 8) | acc_data[0])) >> 4);
	hw_d[1] = (((s16)((acc_data[3] << 8) | acc_data[2])) >> 4);
	hw_d[2] = (((s16)((acc_data[5] << 8) | acc_data[4])) >> 4);

	hw_d[0] = hw_d[0] * acc->sensitivity;
	hw_d[1] = hw_d[1] * acc->sensitivity;
	hw_d[2] = hw_d[2] * acc->sensitivity;

	xyz[0] = ((acc->pdata->negate_x) ? (-hw_d[acc->pdata->axis_map_x])
		  : (hw_d[acc->pdata->axis_map_x]));
	xyz[1] = ((acc->pdata->negate_y) ? (-hw_d[acc->pdata->axis_map_y])
		  : (hw_d[acc->pdata->axis_map_y]));
	xyz[2] = ((acc->pdata->negate_z) ? (-hw_d[acc->pdata->axis_map_z])
		  : (hw_d[acc->pdata->axis_map_z]));

	return err;
}

static void ais3624dq_acc_report_values(struct ais3624dq_acc_data *acc,
					int *xyz)
{
	input_event(acc->input_dev, INPUT_EVENT_TYPE, INPUT_EVENT_X,
		    xyz[0]);
	input_event(acc->input_dev, INPUT_EVENT_TYPE, INPUT_EVENT_Y,
		    xyz[1]);
	input_event(acc->input_dev, INPUT_EVENT_TYPE, INPUT_EVENT_Z,
		    xyz[2]);
	input_sync(acc->input_dev);
}

int ais3624dq_acc_enable(struct ais3624dq_acc_data *acc)
{
	if (!atomic_cmpxchg(&acc->enabled, 0, 1)) {
		int err;

		mutex_lock(&acc->lock);
		err = ais3624dq_acc_device_power_on(acc);
		if (err < 0) {
			atomic_set(&acc->enabled, 0);
			mutex_unlock(&acc->lock);
			return err;
		}
		schedule_delayed_work(&acc->input_work,
			msecs_to_jiffies(acc->pdata->poll_interval));
		mutex_unlock(&acc->lock);
	}

	return 0;
}
EXPORT_SYMBOL(ais3624dq_acc_enable);

int ais3624dq_acc_disable(struct ais3624dq_acc_data *acc)
{
	if (atomic_cmpxchg(&acc->enabled, 1, 0)) {
		cancel_delayed_work_sync(&acc->input_work);

		mutex_lock(&acc->lock);
		ais3624dq_acc_device_power_off(acc);
		mutex_unlock(&acc->lock);
	}

	return 0;
}
EXPORT_SYMBOL(ais3624dq_acc_disable);

static ssize_t read_single_reg(struct device *dev, char *buf, u8 reg)
{
	u8 data;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	int rc = 0;

	mutex_lock(&acc->lock);
	rc = acc->tf->read(acc->dev, reg, 1, &data);
	mutex_unlock(&acc->lock);

	/*TODO: error need to be managed */
	return sprintf(buf, "0x%02x\n", data);
}

static int write_reg(struct device *dev, const char *buf, u8 reg)
{
	int rc = 0;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	u8 x[1];
	unsigned long val;

	if (strict_strtoul(buf, 16, &val))
		return -EINVAL;

	mutex_lock(&acc->lock);
	x[0] = val;
	rc = acc->tf->write(acc->dev, reg, 1, x);
	mutex_unlock(&acc->lock);

	/*TODO: error need to be managed */
	return rc;
}

static ssize_t attr_get_polling_rate(struct device *dev,
				     struct device_attribute *attr, char *buf)
{
	int val;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);

	mutex_lock(&acc->lock);
	val = acc->pdata->poll_interval;
	mutex_unlock(&acc->lock);

	return sprintf(buf, "%d\n", val);
}

static ssize_t attr_set_polling_rate(struct device *dev,
				     struct device_attribute *attr,
				     const char *buf, size_t size)
{
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	unsigned long interval_ms;

	if (strict_strtoul(buf, 10, &interval_ms))
		return -EINVAL;
	if (!interval_ms)
		return -EINVAL;

	mutex_lock(&acc->lock);
	acc->pdata->poll_interval = interval_ms;
	ais3624dq_acc_update_odr(acc, interval_ms);
	mutex_unlock(&acc->lock);

	return size;
}

static ssize_t attr_get_range(struct device *dev,
			      struct device_attribute *attr, char *buf)
{
	char val;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	char range = 2;

	mutex_lock(&acc->lock);
	val = acc->pdata->g_range ;
	switch (val) {
	case AIS3624DQ_ACC_G_6G:
		range = 6;
		break;
	case AIS3624DQ_ACC_G_12G:
		range = 12;
		break;
	case AIS3624DQ_ACC_G_24G:
		range = 24;
		break;
	}
	mutex_unlock(&acc->lock);

	return sprintf(buf, "%d\n", range);
}

static ssize_t attr_set_range(struct device *dev,
			      struct device_attribute *attr,
			      const char *buf, size_t size)
{
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	unsigned long val;

	if (strict_strtoul(buf, 10, &val))
		return -EINVAL;

	mutex_lock(&acc->lock);
	acc->pdata->g_range = val;
	ais3624dq_acc_update_g_range(acc, val);
	mutex_unlock(&acc->lock);

	return size;
}

static ssize_t attr_get_enable(struct device *dev,
			       struct device_attribute *attr, char *buf)
{
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	int val = atomic_read(&acc->enabled);
	return sprintf(buf, "%d\n", val);
}

static ssize_t attr_set_enable(struct device *dev,
			       struct device_attribute *attr,
			       const char *buf, size_t size)
{
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	unsigned long val;

	if (strict_strtoul(buf, 10, &val))
		return -EINVAL;

	if (val)
		ais3624dq_acc_enable(acc);
	else
		ais3624dq_acc_disable(acc);

	return size;
}

static ssize_t attr_get_selftest(struct device *dev,
				 struct device_attribute *attr, char *buf)
{
	int val;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);

	mutex_lock(&acc->lock);
	val = acc->selftest_enabled;
	mutex_unlock(&acc->lock);

	return sprintf(buf, "%d\n", val);
}

static ssize_t attr_set_selftest(struct device *dev,
				 struct device_attribute *attr,
				 const char *buf, size_t size)
{
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	unsigned long val;

	if (strict_strtoul(buf, 10, &val))
		return -EINVAL;

	ais3624dq_acc_selftest(acc, val);

	return size;
}

static ssize_t attr_set_intconfig1(struct device *dev,
				   struct device_attribute *attr,
				   const char *buf, size_t size)
{
	return write_reg(dev, buf, INT_CFG1);
}

static ssize_t attr_get_intconfig1(struct device *dev,
				   struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_CFG1);
}

static ssize_t attr_set_duration1(struct device *dev,
				  struct device_attribute *attr,
				  const char *buf, size_t size)
{
	return write_reg(dev, buf, INT_DUR1);
}

static ssize_t attr_get_duration1(struct device *dev,
				  struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_DUR1);
}

static ssize_t attr_set_thresh1(struct device *dev,
				struct device_attribute *attr,
				const char *buf, size_t size)
{
	return write_reg(dev, buf, INT_THS1);
}

static ssize_t attr_get_thresh1(struct device *dev,
				struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_THS1);
}

static ssize_t attr_get_source1(struct device *dev,
				struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_SRC1);
}

static ssize_t attr_set_intconfig2(struct device *dev,
				   struct device_attribute *attr,
				   const char *buf, size_t size)
{
	return write_reg(dev, buf, INT_CFG2);
}

static ssize_t attr_get_intconfig2(struct device *dev,
				   struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_CFG2);
}

static ssize_t attr_set_duration2(struct device *dev,
				  struct device_attribute *attr,
				  const char *buf, size_t size)
{
	return write_reg(dev, buf, INT_DUR2);
}

static ssize_t attr_get_duration2(struct device *dev,
				  struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_DUR2);
}

static ssize_t attr_set_thresh2(struct device *dev,
				struct device_attribute *attr,
				const char *buf, size_t size)
{
	return write_reg(dev, buf, INT_THS2);
}

static ssize_t attr_get_thresh2(struct device *dev,
				struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_THS2);
}
static ssize_t attr_get_source2(struct device *dev,
				struct device_attribute *attr, char *buf)
{
	return read_single_reg(dev, buf, INT_SRC2);
}

#ifdef AIS3624DQ_DEBUG
/* PAY ATTENTION: These AIS3624DQ_DEBUG funtions don't manage resume_state */
static ssize_t attr_reg_set(struct device *dev, struct device_attribute *attr,
			    const char *buf, size_t size)
{
	int rc;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	u8 x[2];
	unsigned long val;

	if (strict_strtoul(buf, 16, &val))
		return -EINVAL;

	mutex_lock(&acc->lock);
	x[0] = val;
	rc = acc->tf->write(acc->dev, acc->reg_addr, 1, x);
	mutex_unlock(&acc->lock);

	/*TODO: error need to be managed */
	return size;
}

static ssize_t attr_reg_get(struct device *dev, struct device_attribute *attr,
			    char *buf)
{
	ssize_t ret;
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	int rc;
	u8 data;

	mutex_lock(&acc->lock);
	err = acc->tf->read(acc->dev, acc->reg_addr, 1, &data);
	mutex_unlock(&acc->lock);

	/*TODO: error need to be managed */
	ret = sprintf(buf, "0x%02x\n", data);
	return ret;
}

static ssize_t attr_addr_set(struct device *dev, struct device_attribute *attr,
			     const char *buf, size_t size)
{
	struct ais3624dq_acc_data *acc = dev_get_drvdata(dev);
	unsigned long val;

	if (strict_strtoul(buf, 16, &val))
		return -EINVAL;

	mutex_lock(&acc->lock);
	acc->reg_addr = val;
	mutex_unlock(&acc->lock);

	return size;
}
#endif

static struct device_attribute attributes[] =
{
	__ATTR(pollrate_ms, 0664, attr_get_polling_rate, attr_set_polling_rate),
	__ATTR(range, 0664, attr_get_range, attr_set_range),
	__ATTR(enable_device, 0664, attr_get_enable, attr_set_enable),
	__ATTR(enable_selftest, 0664, attr_get_selftest, attr_set_selftest),
	__ATTR(int1_config, 0664, attr_get_intconfig1, attr_set_intconfig1),
	__ATTR(int1_duration, 0664, attr_get_duration1, attr_set_duration1),
	__ATTR(int1_threshold, 0664, attr_get_thresh1, attr_set_thresh1),
	__ATTR(int1_source, 0444, attr_get_source1, NULL),
	__ATTR(int2_config, 0664, attr_get_intconfig2, attr_set_intconfig2),
	__ATTR(int2_duration, 0664, attr_get_duration2, attr_set_duration2),
	__ATTR(int2_threshold, 0664, attr_get_thresh2, attr_set_thresh2),
	__ATTR(int2_source, 0444, attr_get_source2, NULL),
#ifdef AIS3624DQ_DEBUG
	__ATTR(reg_value, 0600, attr_reg_get, attr_reg_set),
	__ATTR(reg_addr, 0200, NULL, attr_addr_set),
#endif
};

static int create_sysfs_interfaces(struct device *dev)
{
	int i;
	for (i = 0; i < ARRAY_SIZE(attributes); i++)
		if (device_create_file(dev, attributes + i))
			goto error;
	return 0;

error:
	for ( ; i >= 0; i--)
		device_remove_file(dev, attributes + i);
	dev_err(dev, "%s:Unable to create interface\n", __func__);

	return -1;
}

static int remove_sysfs_interfaces(struct device *dev)
{
	int i;
	for (i = 0; i < ARRAY_SIZE(attributes); i++)
		device_remove_file(dev, attributes + i);

	return 0;
}

static void ais3624dq_acc_input_work_func(struct work_struct *work)
{
	struct ais3624dq_acc_data *acc;
	int xyz[3] = { 0 };
	int err;

	acc = container_of((struct delayed_work *)work,
			   struct ais3624dq_acc_data, input_work);

	mutex_lock(&acc->lock);
	err = ais3624dq_acc_get_acceleration_data(acc, xyz);
	if (err < 0)
		dev_err(acc->dev, "get_acceleration_data failed\n");
	else
		ais3624dq_acc_report_values(acc, xyz);

	schedule_delayed_work(&acc->input_work,
			      msecs_to_jiffies(acc->pdata->poll_interval));
	mutex_unlock(&acc->lock);
}

static int ais3624dq_acc_validate_pdata(struct ais3624dq_acc_data *acc)
{
	acc->pdata->poll_interval = max(acc->pdata->poll_interval,
					acc->pdata->min_interval);

	if (acc->pdata->axis_map_x > 2 || acc->pdata->axis_map_y > 2 ||
	    acc->pdata->axis_map_z > 2) {
		dev_err(acc->dev,
			"invalid axis_map value x:%u y:%u z%u\n",
			acc->pdata->axis_map_x, acc->pdata->axis_map_y,
			acc->pdata->axis_map_z);
		return -EINVAL;
	}

	/* Only allow 0 and 1 for negation boolean flag */
	if (acc->pdata->negate_x > 1 || acc->pdata->negate_y > 1 ||
	    acc->pdata->negate_z > 1) {
		dev_err(acc->dev,
			"invalid negate value x:%u y:%u z:%u\n",
			acc->pdata->negate_x, acc->pdata->negate_y,
			acc->pdata->negate_z);
		return -EINVAL;
	}

	/* Enforce minimum polling interval */
	if (acc->pdata->poll_interval < acc->pdata->min_interval) {
		dev_err(acc->dev, "minimum poll interval violated\n");
		return -EINVAL;
	}

	return 0;
}

static int ais3624dq_acc_input_init(struct ais3624dq_acc_data *acc)
{
	int err;

	INIT_DELAYED_WORK(&acc->input_work, ais3624dq_acc_input_work_func);
	acc->input_dev = input_allocate_device();
	if (!acc->input_dev) {
		dev_err(acc->dev, "input device allocation failed\n");
		return -ENOMEM;
	}

	acc->input_dev->name = AIS3624DQ_ACC_DEV_NAME;
	acc->input_dev->id.bustype = acc->bus_type;
	acc->input_dev->dev.parent = acc->dev;

	input_set_drvdata(acc->input_dev, acc);

	set_bit(INPUT_EVENT_TYPE, acc->input_dev->evbit);
	set_bit(INPUT_EVENT_X, acc->input_dev->mscbit);
	set_bit(INPUT_EVENT_Y, acc->input_dev->mscbit);
	set_bit(INPUT_EVENT_Z, acc->input_dev->mscbit);

	err = input_register_device(acc->input_dev);
	if (err) {
		dev_err(acc->dev,
			"unable to register input device %s\n",
			acc->input_dev->name);
		input_free_device(acc->input_dev);
	}

	return err;
}

static void ais3624dq_acc_input_cleanup(struct ais3624dq_acc_data *acc)
{
	input_unregister_device(acc->input_dev);
	input_free_device(acc->input_dev);
}

int ais3624dq_acc_probe(struct ais3624dq_acc_data *acc)
{
	int err = -1;

	if (acc->dev->platform_data == NULL) {
		dev_err(acc->dev, "platform data is NULL. exiting.\n");
		return -ENODEV;
	}

	mutex_lock(&acc->lock);

	acc->pdata = kmalloc(sizeof(*acc->pdata), GFP_KERNEL);
	if (acc->pdata == NULL) {
		err = -ENOMEM;
		dev_err(acc->dev,
			"failed to allocate memory for pdata: %d\n",
			err);
		goto err_mutexunlock;
	}

	memcpy(acc->pdata, acc->dev->platform_data, sizeof(*acc->pdata));

	err = ais3624dq_acc_validate_pdata(acc);
	if (err < 0) {
		dev_err(acc->dev, "failed to validate platform data\n");
		goto exit_kfree_pdata;
	}

	if (acc->pdata->init) {
		err = acc->pdata->init();
		if (err < 0) {
			dev_err(acc->dev, "init failed: %d\n", err);
			goto err_pdata_init;
		}
	}

	if(acc->pdata->gpio_int1 >= 0){
		acc->irq1 = gpio_to_irq(acc->pdata->gpio_int1);
		printk(KERN_INFO "%s: %s has set irq1 to irq: %d "
		       "mapped on gpio:%d\n", AIS3624DQ_ACC_DEV_NAME,
		       __func__, acc->irq1, acc->pdata->gpio_int1);
	}

	if(acc->pdata->gpio_int2 >= 0){
		acc->irq2 = gpio_to_irq(acc->pdata->gpio_int2);
		printk(KERN_INFO "%s: %s has set irq2 to irq: %d "
		       "mapped on gpio:%d\n", AIS3624DQ_ACC_DEV_NAME,
		       __func__, acc->irq2, acc->pdata->gpio_int2);
	}

	memset(acc->resume_state, 0, ARRAY_SIZE(acc->resume_state));

	acc->resume_state[RES_CTRL_REG1] = AIS3624DQ_ACC_ENABLE_ALL_AXES;
	acc->resume_state[RES_CTRL_REG4] = AIS3624DQ_ACC_BDU_EN;

	err = ais3624dq_acc_device_power_on(acc);
	if (err < 0) {
		dev_err(acc->dev, "power on failed: %d\n", err);
		goto err_pdata_init;
	}

	atomic_set(&acc->enabled, 1);

	err = ais3624dq_acc_update_g_range(acc, acc->pdata->g_range);
	if (err < 0) {
		dev_err(acc->dev, "update_g_range failed\n");
		goto err_power_off;
	}

	err = ais3624dq_acc_update_odr(acc, acc->pdata->poll_interval);
	if (err < 0) {
		dev_err(acc->dev, "update_odr failed\n");
		goto err_power_off;
	}

	err = ais3624dq_acc_input_init(acc);
	if (err < 0) {
		dev_err(acc->dev, "input init failed\n");
		goto err_power_off;
	}


	err = create_sysfs_interfaces(acc->dev);
	if (err < 0) {
		dev_err(acc->dev,
			"device AIS3624DQ_ACC_DEV_NAME "
			"sysfs register failed\n");
		goto err_input_cleanup;
	}

	ais3624dq_acc_device_power_off(acc);

	/* As default, do not report information */
	atomic_set(&acc->enabled, 0);

	if(acc->pdata->gpio_int1 >= 0){
		INIT_WORK(&acc->irq1_work, ais3624dq_acc_irq1_work_func);
		acc->irq1_work_queue =
			create_singlethread_workqueue("ais3624dq_acc_wq1");
		if (!acc->irq1_work_queue) {
			err = -ENOMEM;
			dev_err(acc->dev,
				"cannot create work queue1: %d\n", err);
			goto err_remove_sysfs_int;
		}
		err = request_irq(acc->irq1, ais3624dq_acc_isr1,
				  IRQF_TRIGGER_RISING, "ais3624dq_acc_irq1", acc);
		if (err < 0) {
			dev_err(acc->dev, "request irq1 failed: %d\n", err);
			goto err_destoyworkqueue1;
		}
		disable_irq_nosync(acc->irq1);
	}

	if(acc->pdata->gpio_int2 >= 0){
		INIT_WORK(&acc->irq2_work, ais3624dq_acc_irq2_work_func);
		acc->irq2_work_queue =
			create_singlethread_workqueue("ais3624dq_acc_wq2");
		if (!acc->irq2_work_queue) {
			err = -ENOMEM;
			dev_err(acc->dev,
				"cannot create work queue2: %d\n", err);
			goto err_free_irq1;
		}
		err = request_irq(acc->irq2, ais3624dq_acc_isr2,
			IRQF_TRIGGER_RISING, "ais3624dq_acc_irq2", acc);
		if (err < 0) {
			dev_err(acc->dev, "request irq2 failed: %d\n", err);
				goto err_destoyworkqueue2;
		}
		disable_irq_nosync(acc->irq2);
	}

	mutex_unlock(&acc->lock);

	return 0;

err_destoyworkqueue2:
	if(acc->pdata->gpio_int2 >= 0)
		destroy_workqueue(acc->irq2_work_queue);
err_free_irq1:
	free_irq(acc->irq1, acc);
err_destoyworkqueue1:
	if(acc->pdata->gpio_int1 >= 0)
		destroy_workqueue(acc->irq1_work_queue);
err_remove_sysfs_int:
	remove_sysfs_interfaces(acc->dev);
err_input_cleanup:
	ais3624dq_acc_input_cleanup(acc);
err_power_off:
	ais3624dq_acc_device_power_off(acc);
err_pdata_init:
	if (acc->pdata->exit)
		acc->pdata->exit();
exit_kfree_pdata:
	kfree(acc->pdata);
err_mutexunlock:
	mutex_unlock(&acc->lock);

	return err;
}
EXPORT_SYMBOL(ais3624dq_acc_probe);

int ais3624dq_acc_remove(struct ais3624dq_acc_data *acc)
{
	if (acc->pdata->gpio_int1 >= 0){
		free_irq(acc->irq1, acc);
		gpio_free(acc->pdata->gpio_int1);
		destroy_workqueue(acc->irq1_work_queue);
	}

	if (acc->pdata->gpio_int2 >= 0){
		free_irq(acc->irq2, acc);
		gpio_free(acc->pdata->gpio_int2);
		destroy_workqueue(acc->irq2_work_queue);
	}

	ais3624dq_acc_input_cleanup(acc);
	ais3624dq_acc_device_power_off(acc);
	remove_sysfs_interfaces(acc->dev);

	if (acc->pdata->exit)
		acc->pdata->exit();
	kfree(acc->pdata);

	return 0;
}
EXPORT_SYMBOL(ais3624dq_acc_remove);

MODULE_DESCRIPTION("ais3624dq accelerometer sysfs driver");
MODULE_AUTHOR("Matteo Dameno, STMicroelectronics");
MODULE_AUTHOR("Lorenzo Bianconi, STMicroelectronics");
MODULE_AUTHOR("Mario Tesi, STMicroelectronics");
MODULE_LICENSE("GPL v2");
